import Gumul from './gumul'

const test = new Gumul('test')
test.load()

const test2 = new Gumul('test2')